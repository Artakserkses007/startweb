<?php

$sql = "SELECT * FROM users";
$res = $db->query($sql);