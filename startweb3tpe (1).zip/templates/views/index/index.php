<section class="content">
    <div class="container">
        <h1>Widok domyślny</h1>
        <h2><a href="?page=index&action=users" title="lista">zobacz listę użytkowników</a></h2>
        <h2><a href="?page=index&action=add" title="dodawanie">dodaj użytkownika</a></h2>
        <h2><a href="logout.php" title="wyloguj">wyloguj</a></h2>
    </div>
</section>